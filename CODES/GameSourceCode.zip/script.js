    var icons = ["bath", "bug", "bowling-ball", "coffee", "couch", "football-ball", "gem", "laptop"];
    var score;
    var gameplay;
    var reqUpdate;
    var mDown = false;
    var BGcount;
    var hazards;
    var container = document.querySelector('.container');
    var crossHair = document.querySelector('.crossHair');
    var gameover = document.querySelector('.gameover');
    var baddy = document.querySelector('.baddy');
    var btnStart = document.querySelector('.btnStart');
    var myContainer = {
        width: container.offsetWidth
        , height: container.offsetHeight
        , left: container.offsetLeft
        , top: container.offsetTop
    }
    container.addEventListener('mousemove', move, true);
    btnStart.addEventListener('click', startGame);
    container.addEventListener('mousedown', mouseDown, true);

    function mouseDown(e) {
        if (gameplay) {
            var div = document.createElement('div');
            div.setAttribute('class', 'fireme');
            div.style.left = (e.clientX - 100) + 'px';
            div.style.top = (e.clientY - 100) + 'px';
            div.dataset.counter = 100;
            div.style.width = 100 + 'px';
            div.style.height = 100 + 'px';
            container.appendChild(div);
        }
    }

    function startGame() {
        if (!gameplay) {
            BGcount = 100;
            score = 0;
            hazards = 3;
            setupBadguys(20);
            gameplay = true;
            gameover.style.display = 'none';
            reqUpdate = window.requestAnimationFrame(update);
        }
    }

    function endGame() {
        gameover.style.display = 'block';
        gameover.innerHTML = 'GAME OVER <br>SCORE ' + score;
        gameplay = false;
        var tempEnemy = document.querySelectorAll('.baddy');
        for (var e of tempEnemy) {
            e.parentNode.removeChild(e);
        }
        var tempFire = document.querySelectorAll('.fireme');
        for (var e of tempFire) {
            e.parentNode.removeChild(e);
        }
    }

    function setupBadguys(num) {
        for (var x = 0; x < num; x++) {
            badMaker();
        }
    }

    function randomColor() {
        function c() {
            var hex = Math.floor(Math.random() * 256).toString(16);
            var response = ("0" + String(hex)).substr(-2);
            return response;
        }
        return '#' + c() + c() + c();
    }

    function badMaker() {
        var div = document.createElement('div');
        var randomWidth;
        var iconRan;
        if (hazards > 0) {
            hazards--;
            iconRan = "fa-bomb";
            div.dataset.points = 0;
            div.style.color = 'white';
            div.style.backgroundColor = 'black';
            randomWidth = 150;
        }
        else {
            iconRan = "fa-" + icons[Math.floor(Math.random() * (icons.length))];
            div.dataset.points = Math.ceil(Math.random() * 10) + 2;
            randomWidth = Math.floor(Math.random() * 50) + 50;
            div.style.color = randomColor();
        }
        var x = Math.floor(Math.random() * (myContainer.width - randomWidth));
        var y = Math.floor(Math.random() * (myContainer.height - randomWidth));
        div.innerHTML = '<i class="fas ' + iconRan + '"></i>';
        div.setAttribute('class', 'baddy');
        div.dataset.speed = Math.ceil(Math.random() * 10) + 2;
        div.dataset.dir = Math.ceil(Math.random() * 8);
        div.dataset.mover = Math.ceil(Math.random() * 15) + 2;
        div.style.fontSize = randomWidth + 'px';
        div.style.lineHeight = randomWidth - (randomWidth * 0.3) + 'px';
        div.style.height = randomWidth + 'px';
        div.style.left = x + 'px';
        div.style.top = y + 'px';
        container.appendChild(div);
    }

    function update() {
        //ANIMATION
        var tempShots = document.querySelectorAll('.fireme');
        for (var shot of tempShots) {
            fireMover(shot);
        }
        var tempEnemy = document.querySelectorAll('.baddy');
        for (var enemy of tempEnemy) {
            itemMover(enemy);
        }
        if (!gameplay) {
            window.cancelAnimationFrame(reqUpdate);
        }
        else {
            reqUpdate = window.requestAnimationFrame(update);
        }
    }

    function fireMover(e) {
        if (e.dataset.counter < 1) {
            e.parentNode.removeChild(e);
        }
        else {
            e.style.left = parseInt(e.style.left) + 1.5 + 'px';
            e.style.top = parseInt(e.style.top) + 1.5 + 'px';
            e.style.width = e.dataset.counter + 'px';
            e.style.height = e.dataset.counter + 'px';
            e.dataset.counter -= 3;
        }
    }

    function scoreUpdate(points) {
        score += parseInt(points);
        document.querySelector('.score').innerText = score;
    }

    function itemMover(e) {
        //
        var tempShots = document.querySelectorAll('.fireme');
        for (var shot of tempShots) {
            if (isCollision(shot, e)) {
                if (e.dataset.points == 0) {
                    endGame();
                    return;
                }
                shot.parentNode.removeChild(shot);
                e.parentNode.removeChild(e);
                scoreUpdate(e.dataset.points);
                badMaker();
                BGcount--;
                if (BGcount < 0) endGame();
                return;
            }
        }
        var x = parseInt(e.style.left);
        var y = parseInt(e.style.top);
        var sp = parseInt(e.dataset.speed);
        if (e.dataset.mover <= 0) {
            e.dataset.speed = Math.ceil(Math.random() * 10) + 2;
            e.dataset.dir = Math.ceil(Math.random() * 8);
            e.dataset.mover = Math.ceil(Math.random() * 15) + 2;
        }
        else {
            e.dataset.mover--;
            if ((e.dataset.dir == '1' || e.dataset.dir == '2' || e.dataset.dir == '8') && x < myContainer.width) {
                x += sp;
            } //right
            if ((e.dataset.dir == '4' || e.dataset.dir == '5' || e.dataset.dir == '6') && x > 0) {
                x -= sp;
            } //left
            if ((e.dataset.dir == '3' || e.dataset.dir == '2' || e.dataset.dir == '4') && y < myContainer.height) {
                y += sp;
            } //down
            if ((e.dataset.dir == '7' || e.dataset.dir == '6' || e.dataset.dir == '8') && y > 0) {
                y -= sp;
            } //up
        }
        e.style.left = x + 'px';
        e.style.top = y + 'px';
    }

    function isCollision(a, b) {
        var aRect = a.getBoundingClientRect();
        var bRect = b.getBoundingClientRect();
        return !(
            ((aRect.top + aRect.height) < bRect.top) || ((bRect.top + bRect.height) < aRect.top) || ((aRect.left + aRect.width) < bRect.left) || ((bRect.left + bRect.width) < aRect.left))
    }

    function move(e) {
        document.querySelector('.crossInfo').innerHTML = 'X:' + (e.clientX - 50) + '- Y:' + (e.clientY - 50);
        crossHair.style.left = (e.clientX - 100) + 'px';
        crossHair.style.top = (e.clientY - 100) + 'px';
    }